#..............................................................
#QuickBite Food Ordering System
#CCU1304 Fundamentals of Programming
#Sample Solution
#..............................................................

delivery_rate=50
free_delivery_limit=5000
max_distance=20


#.............................................................
#Functinal to calculate discount
#.............................................................

def calculate_discount(order_type,food_subtotal):
    if order_type=="PREMIUM":
        return food_subtotal*0.10
    elif order_type=="VIP":
        return food_subtotal*0.20
    else:
        return 0
    
#............................................................
#Functional to calculate delivery
#............................................................
    
def calculate_delivery(food_subtotal,distance):
    if food_subtotal>free_delivery_limit:
        return 0
    else:
        return distance*delivery_rate
    
#..........................................................
#Main Program
#..........................................................
    
print("="*50)
print("QUICKBITE FOOD ORDER SYSREM")
print("="*50)

#Customer Name
customer_name=input("Enter customer name:")

#Order Type Validation
while True:
    order_type=input("Enter Order Type(Regular/Premium/VIP):").upper()
    
    if order_type in["REGULAR","PREMIUM","VIP"]:
        break
    else:
        print("Invaid order type.Please try again.")
        
#Number of Items Validation
while True:
    try:
        number_of_items=int(input("Enter number of food items:"))
        if number_of_items>0:
            break
        else:
            print("Number of items must be greater than zero.")
    except:
        print("Please enter a valid integer.")
        
#Price Validation
while True:
    try:
        price_per_item=float(input("Enter price per item(Rs.):"))
        if price_per_item>0:
            break
        else:
            print("Price must be greater than zero.")
    except:
        print("Please enter a valid price.")
        
#Delivery Distance Validation
while True:
    try:
        distance=float(input("Enter delivery distance(km):"))
        
        if 0<=distance<=max_distance:
            break
        else:
            print("Delivery distance must be between 0 and 20 km.")
    except:
        print("Please enter a valid distance.")
        
#Discount Eligibility
while True:
    eligibility=input("Eligible for Special Discount?(Y/N):").upper()
    
    if eligibility in["Y","N"]:
        break
    else:
        print("Please enter Y or N.")
    
#..........................................................
#Calculations
#..........................................................
        
food_subtotal=number_of_items*price_per_item

discount=calculate_discount(order_type,food_subtotal)

#Additinal promotional discount
if eligibility=="Y":
    discount+=food_subtotal*0.05
    
delivery_rate=calculate_delivery(food_subtotal,distance)

total_payable=food_subtotal+delivery_rate-discount

#..........................................................
#Output
#...........................................................

print("\n")
print("="*50)
print("QUICKBITE ORDER BILL")
print("="*50)

print(f"Customer Name         : {customer_name}")
print(f"Order Type            : {order_type.title()}")
print(f"Food Items            : {number_of_items}")
print(f"Price Per Item        : Rs.{price_per_item:.2f}")
print(f"Food Subtotal         : Rs.{food_subtotal:.2f}")
print(f"Discount              : Rs.{discount:.2f}")
print(f"Delivery_rate       : Rs.{delivery_rate:.2f}")

print("="*50)
print(f"TOTAL PAYABLE         : Rs.{total_payable:.2f}")
print("="*50)

print("\nThank you for ordering from QuickBite!")
            
    